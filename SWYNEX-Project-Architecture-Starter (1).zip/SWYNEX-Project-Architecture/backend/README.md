# Backend starter

## Proposed setup

- Java 17 or later
- Spring Boot
- Spring Web
- Spring Data JPA
- Spring Security
- MySQL Driver
- Validation
- Maven

## Suggested package structure

```text
src/main/java/com/swynex/studenttaskmanager/
├── StudentTaskManagerApplication.java
├── config/
├── controller/
├── dto/
├── entity/
├── exception/
├── repository/
└── service/
```

## Implementation order

1. Create the Spring Boot project.
2. Configure MySQL using environment variables.
3. Create User, Subject, and Task entities.
4. Create repositories.
5. Implement subject and task services.
6. Implement REST controllers and validation.
7. Add authentication and authorization.
8. Test endpoints using Postman.

Do not commit database passwords, signing secrets, or other credentials.
