# Frontend starter

## Planned screens

1. Login
2. Registration
3. Dashboard
4. My Tasks
5. Add / Edit Task
6. Subjects

## Suggested initial files

```text
frontend/
├── index.html
├── css/
│   └── styles.css
└── js/
    └── app.js
```

## Responsibilities

- Render responsive screens.
- Validate form fields for quick user feedback.
- Call the backend REST API using `fetch`.
- Display loading, success, empty, and error states.
- Never treat frontend validation as a replacement for backend validation.

The frontend is not yet implemented in this architecture starter.
