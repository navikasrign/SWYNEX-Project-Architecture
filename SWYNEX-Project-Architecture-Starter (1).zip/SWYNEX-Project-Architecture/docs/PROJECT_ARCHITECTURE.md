# Project Architecture – Student Task Manager

**Internship:** SWYNEX Technologies  
**Task:** 1 – Project Architecture  
**Project name:** Student Task Manager  
**Document status:** Architecture and starter design  
**Version:** 1.0

---

## 1. Project overview

### 1.1 Product idea

Student Task Manager is a web application that helps students organize academic work in one place. A student can create tasks, associate them with subjects, set due dates, update task status, and review progress through a dashboard.

### 1.2 Problem statement

Students commonly manage assignments, homework, projects, and exam preparation across notebooks, messages, and separate applications. This can make it difficult to remember deadlines and identify unfinished work.

### 1.3 Proposed solution

Provide a simple dashboard where a student can:
- Register and sign in.
- Create, view, edit, and delete academic tasks.
- Organize tasks by subject.
- Set due dates and priorities.
- Mark tasks as pending, in progress, or completed.
- Identify overdue tasks.
- View a summary of task progress.

### 1.4 Target users

The initial target users are school and college students who need a lightweight way to manage academic tasks.

### 1.5 Objectives

1. Centralize academic task information.
2. Make upcoming deadlines visible.
3. Help students prioritize work.
4. Make task progress easy to track.
5. Keep each student's data private to their account.

---

## 2. Scope

### 2.1 Minimum viable product (MVP)

Included in the first implementation:
- User registration and login.
- Dashboard summary.
- Subject creation and listing.
- Task creation, listing, editing, and deletion.
- Task status and priority.
- Due-date display and overdue identification.
- Filtering tasks by status, subject, and due date.

### 2.2 Out of scope for the first version

The following can be considered for future versions:
- Push notifications and email reminders.
- Calendar synchronization.
- Team collaboration and shared tasks.
- AI-based study planning.
- File attachments.
- Mobile applications.

### 2.3 Assumptions

- A user has one account and can create multiple subjects.
- A subject can contain multiple tasks.
- Every task belongs to exactly one user.
- A task may optionally be associated with a subject.
- Dates are stored in the database and displayed in the user's local timezone.
- The first version is a single-user task manager, not a collaborative platform.

---

## 3. Functional requirements

| ID | Requirement | Description |
|---|---|---|
| FR-01 | Registration | A new student can create an account. |
| FR-02 | Login | A registered student can sign in. |
| FR-03 | Subject management | A student can add and view subjects. |
| FR-04 | Create task | A student can create a task with a title and due date. |
| FR-05 | View tasks | A student can view their own tasks. |
| FR-06 | Update task | A student can edit task details. |
| FR-07 | Delete task | A student can delete a task. |
| FR-08 | Update status | A student can change task status. |
| FR-09 | Dashboard | The application displays task counts and upcoming work. |
| FR-10 | Filter tasks | A student can filter tasks by status or subject. |

## 4. Non-functional requirements

- **Security:** Passwords must be stored as secure hashes, never as plain text.
- **Authorization:** A user must only access their own subjects and tasks.
- **Usability:** Screens should be responsive and straightforward to navigate.
- **Maintainability:** Frontend, backend, and database responsibilities should remain separate.
- **Reliability:** Validate input on both frontend and backend.
- **Performance:** Use pagination if task lists become large.
- **Data integrity:** Use primary keys, foreign keys, and appropriate constraints.

---

## 5. Technology stack and responsibilities

| Layer | Technology | Responsibility |
|---|---|---|
| Frontend | HTML, CSS, JavaScript | Screens, forms, validation feedback, API calls |
| Backend | Java 17+ / Spring Boot | Business logic, authentication, authorization, validation |
| API | REST / JSON | Communication between frontend and backend |
| Database | MySQL 8.0+ | Persistent user, subject, and task records |
| API testing | Postman | Verify requests, responses, and error cases |
| Version control | Git / GitHub | Track source code and documentation |

### Why this stack?

Java and Spring Boot provide a structured way to build backend services and REST APIs. MySQL stores relational data such as users, subjects, and tasks. HTML, CSS, and JavaScript provide a beginner-friendly frontend foundation.

---

## 6. Data model

The MVP uses three main entities: `users`, `subjects`, and `tasks`.

### 6.1 Users

| Field | Type | Key / rule | Purpose |
|---|---|---|---|
| user_id | BIGINT | Primary key, auto increment | Unique user identifier |
| full_name | VARCHAR(100) | Not null | Student's name |
| email | VARCHAR(150) | Unique, not null | Login identifier |
| password_hash | VARCHAR(255) | Not null | Secure password hash |
| created_at | TIMESTAMP | Default current timestamp | Account creation time |
| updated_at | TIMESTAMP | Auto update | Last update time |

### 6.2 Subjects

| Field | Type | Key / rule | Purpose |
|---|---|---|---|
| subject_id | BIGINT | Primary key, auto increment | Unique subject identifier |
| user_id | BIGINT | Foreign key to users | Subject owner |
| subject_name | VARCHAR(100) | Not null | Subject title |
| subject_code | VARCHAR(30) | Nullable | Optional course code |
| created_at | TIMESTAMP | Default current timestamp | Creation time |

### 6.3 Tasks

| Field | Type | Key / rule | Purpose |
|---|---|---|---|
| task_id | BIGINT | Primary key, auto increment | Unique task identifier |
| user_id | BIGINT | Foreign key to users | Task owner |
| subject_id | BIGINT | Nullable foreign key to subjects | Related subject |
| title | VARCHAR(150) | Not null | Task title |
| description | TEXT | Nullable | Additional details |
| due_date | DATE | Nullable | Deadline |
| priority | ENUM | LOW, MEDIUM, HIGH | Importance |
| status | ENUM | PENDING, IN_PROGRESS, COMPLETED | Progress |
| created_at | TIMESTAMP | Default current timestamp | Creation time |
| updated_at | TIMESTAMP | Auto update | Last update time |

### 6.4 Relationships

- One user can have many subjects (one-to-many).
- One user can have many tasks (one-to-many).
- One subject can have many tasks (one-to-many).
- A task belongs to one user and may be linked to one subject.

The backend must verify that a selected subject belongs to the currently authenticated user before attaching it to a task.

---

## 7. API design overview

Base URL during local development: `http://localhost:8080/api`

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/auth/register` | Create a user account |
| POST | `/auth/login` | Authenticate a user |
| GET | `/subjects` | List current user's subjects |
| POST | `/subjects` | Create a subject |
| PUT | `/subjects/{subjectId}` | Update a subject |
| DELETE | `/subjects/{subjectId}` | Delete a subject |
| GET | `/tasks` | List current user's tasks |
| GET | `/tasks/{taskId}` | Get one task |
| POST | `/tasks` | Create a task |
| PUT | `/tasks/{taskId}` | Update a task |
| PATCH | `/tasks/{taskId}/status` | Update task status |
| DELETE | `/tasks/{taskId}` | Delete a task |
| GET | `/dashboard/summary` | Get dashboard counts |

Detailed request and response examples are in `API_DOCUMENTATION.md`.

---

## 8. Frontend screen plan

### Screen 1 – Login
- Email field.
- Password field.
- Login button.
- Link to registration.
- Validation and error messages.

### Screen 2 – Registration
- Full name.
- Email.
- Password.
- Confirm password (frontend-only confirmation).
- Register button.

### Screen 3 – Dashboard
- Welcome message.
- Total task count.
- Pending task count.
- In-progress task count.
- Completed task count.
- Upcoming deadlines.
- Quick action to add a task.

### Screen 4 – My Tasks
- List or card view of tasks.
- Search by title.
- Filters for status, subject, and priority.
- Edit, delete, and mark-complete actions.

### Screen 5 – Add / Edit Task
- Task title.
- Description.
- Subject selector.
- Due date.
- Priority selector.
- Status selector.
- Save and cancel actions.

### Screen 6 – Subjects
- List of subjects.
- Add subject form.
- Edit and delete actions.

### Navigation flow

1. User opens the application.
2. User signs in or registers.
3. Successful login opens the dashboard.
4. From the dashboard, the user can open My Tasks or Subjects.
5. Add Task opens the task form.
6. Saving a task returns the user to the task list or dashboard.
7. Logout returns the user to the login screen.

---

## 9. System architecture

The frontend sends HTTP requests to the Spring Boot backend. The backend validates the request, applies business rules, and reads or writes data in MySQL. The backend returns a JSON response to the frontend.

See `ARCHITECTURE_DIAGRAM.md` for the Mermaid diagram.

### Backend package proposal

```text
backend/src/main/java/.../
├── controller/
├── service/
├── repository/
├── entity/
├── dto/
├── config/
└── exception/
```

- `controller`: receives HTTP requests and returns responses.
- `service`: contains application/business logic.
- `repository`: communicates with MySQL using Spring Data JPA.
- `entity`: maps Java classes to database tables.
- `dto`: defines request and response data structures.
- `config`: security and application configuration.
- `exception`: centralized error handling.

---

## 10. Validation and error handling

Examples of validation:
- Name and email are required during registration.
- Email must have a valid format and must be unique.
- Password must meet the application's minimum password policy.
- Task title is required.
- Priority and status must match allowed values.
- A due date must be a valid date.
- A subject must belong to the signed-in user.

Suggested HTTP status codes:
- `200 OK`: successful read or update.
- `201 Created`: resource created.
- `204 No Content`: successful deletion.
- `400 Bad Request`: invalid input.
- `401 Unauthorized`: missing or invalid authentication.
- `403 Forbidden`: authenticated user lacks permission.
- `404 Not Found`: resource does not exist or is not accessible.
- `409 Conflict`: duplicate email or conflicting resource.
- `500 Internal Server Error`: unexpected server error.

Do not expose stack traces, password hashes, or sensitive details in API error responses.

---

## 11. Security considerations

- Store passwords using a strong password hashing algorithm such as BCrypt through Spring Security.
- Never store plain-text passwords.
- Protect private API routes with authentication.
- Check resource ownership on every task and subject operation.
- Validate all input on the backend.
- Keep database credentials outside source control, for example in environment variables.
- Use HTTPS when deployed.
- Configure CORS only for the intended frontend origin.
- Do not commit `.env` files or secrets.

For the first implementation, Spring Security with a documented session or token-based approach should be selected before coding authentication.

---

## 12. Development phases

| Phase | Work | Deliverable |
|---|---|---|
| 1 | Architecture and database planning | This document and SQL schema |
| 2 | Frontend structure and screens | Responsive UI |
| 3 | Spring Boot project setup | Running backend |
| 4 | MySQL and entity integration | Persistent data |
| 5 | Subject and task APIs | CRUD operations |
| 6 | Authentication and authorization | Protected user accounts |
| 7 | Frontend-backend integration | Working application |
| 8 | Testing and documentation | Tested MVP and final README |

---

## 13. Acceptance criteria for the MVP

The first usable version is considered complete when:
- A student can register and log in.
- A student can create and view subjects.
- A student can create, edit, view, and delete tasks.
- A student can update task status.
- Dashboard counts reflect the student's tasks.
- Users cannot access another user's tasks or subjects.
- Invalid inputs produce understandable error messages.
- The UI works on desktop and mobile screen sizes.

---

## 14. Future enhancements

- Email or in-app deadline reminders.
- Calendar view.
- Recurring tasks.
- File attachments for assignments.
- Study analytics and productivity charts.
- AI-assisted task prioritization.

---

## 15. Conclusion

Student Task Manager is designed as a small, maintainable web application that addresses a common student problem. The architecture separates the frontend, backend, and database, while the relational data model and REST API provide a clear foundation for implementation.
