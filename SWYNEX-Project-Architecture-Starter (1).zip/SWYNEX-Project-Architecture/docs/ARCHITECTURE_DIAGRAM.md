# System Architecture Diagram

## High-level architecture

```mermaid
flowchart TD
    U[Student] --> B[Web Browser]
    B --> FE[Frontend: HTML, CSS, JavaScript]
    FE -->|HTTP requests / JSON responses| API[Spring Boot REST API]
    API --> C[Controllers]
    C --> S[Service Layer]
    S --> R[Spring Data JPA Repositories]
    R --> DB[(MySQL Database)]
```

## Request flow

```mermaid
sequenceDiagram
    actor Student
    participant UI as Frontend
    participant API as Spring Boot API
    participant Service as Service Layer
    participant DB as MySQL

    Student->>UI: Submit new task form
    UI->>API: POST /api/tasks
    API->>Service: Validate and process request
    Service->>DB: Insert task record
    DB-->>Service: Saved task
    Service-->>API: Task response
    API-->>UI: 201 Created + JSON
    UI-->>Student: Show success and updated task list
```

## Entity relationship diagram

```mermaid
erDiagram
    USERS ||--o{ SUBJECTS : owns
    USERS ||--o{ TASKS : creates
    SUBJECTS o|--o{ TASKS : categorizes

    USERS {
        BIGINT user_id PK
        VARCHAR full_name
        VARCHAR email UK
        VARCHAR password_hash
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    SUBJECTS {
        BIGINT subject_id PK
        BIGINT user_id FK
        VARCHAR subject_name
        VARCHAR subject_code
        TIMESTAMP created_at
    }

    TASKS {
        BIGINT task_id PK
        BIGINT user_id FK
        BIGINT subject_id FK
        VARCHAR title
        TEXT description
        DATE due_date
        ENUM priority
        ENUM status
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
```
