# REST API Documentation – Student Task Manager

**Base URL:** `http://localhost:8080/api`  
**Content type:** `application/json`

> These routes are the planned API contract. They are not live endpoints until the Spring Boot backend is implemented.

## 1. Authentication

### Register
`POST /auth/register`

Request:
```json
{
  "fullName": "Asha Kumar",
  "email": "asha@example.com",
  "password": "ExamplePassword123"
}
```

Success: `201 Created`
```json
{
  "userId": 1,
  "fullName": "Asha Kumar",
  "email": "asha@example.com"
}
```

Never return the password or password hash.

### Login
`POST /auth/login`

Request:
```json
{
  "email": "asha@example.com",
  "password": "ExamplePassword123"
}
```

Success response depends on the authentication approach selected during implementation. The implementation should use secure cookies or a properly protected token; never store raw credentials in browser storage.

## 2. Subjects

All subject routes require authentication.

### List subjects
`GET /subjects`

Success: `200 OK`
```json
[
  {
    "subjectId": 10,
    "subjectName": "Data Structures",
    "subjectCode": "CS201"
  }
]
```

### Create subject
`POST /subjects`

Request:
```json
{
  "subjectName": "Data Structures",
  "subjectCode": "CS201"
}
```

Success: `201 Created`

### Update subject
`PUT /subjects/{subjectId}`

Request:
```json
{
  "subjectName": "Advanced Data Structures",
  "subjectCode": "CS202"
}
```

Success: `200 OK`

### Delete subject
`DELETE /subjects/{subjectId}`

Success: `204 No Content`

If a subject has tasks, implementation must define a safe policy. Recommended MVP behavior: keep tasks and set their `subject_id` to `NULL` (using `ON DELETE SET NULL`).

## 3. Tasks

All task routes require authentication. The backend must scope every query to the authenticated user.

### List tasks
`GET /tasks`

Optional query parameters:
- `status=PENDING`
- `subjectId=10`
- `priority=HIGH`
- `dueBefore=2026-12-31`
- `page=0`
- `size=20`

Success: `200 OK`
```json
[
  {
    "taskId": 101,
    "title": "Complete DSA assignment",
    "description": "Solve the array problems",
    "subjectId": 10,
    "dueDate": "2026-11-20",
    "priority": "HIGH",
    "status": "IN_PROGRESS"
  }
]
```

### Get one task
`GET /tasks/{taskId}`

Success: `200 OK`

### Create task
`POST /tasks`

Request:
```json
{
  "title": "Complete DSA assignment",
  "description": "Solve the array problems",
  "subjectId": 10,
  "dueDate": "2026-11-20",
  "priority": "HIGH",
  "status": "PENDING"
}
```

Success: `201 Created`

### Update task
`PUT /tasks/{taskId}`

Request:
```json
{
  "title": "Complete DSA assignment",
  "description": "Solve the array and string problems",
  "subjectId": 10,
  "dueDate": "2026-11-22",
  "priority": "MEDIUM",
  "status": "IN_PROGRESS"
}
```

Success: `200 OK`

### Update task status
`PATCH /tasks/{taskId}/status`

Request:
```json
{
  "status": "COMPLETED"
}
```

Success: `200 OK`

### Delete task
`DELETE /tasks/{taskId}`

Success: `204 No Content`

## 4. Dashboard

### Get dashboard summary
`GET /dashboard/summary`

Success: `200 OK`
```json
{
  "totalTasks": 12,
  "pendingTasks": 5,
  "inProgressTasks": 3,
  "completedTasks": 4,
  "overdueTasks": 2
}
```

Counts must be calculated only from the authenticated user's tasks. Overdue means the due date is before the current date and the task is not completed.

## 5. Common error response

Example: `400 Bad Request`
```json
{
  "timestamp": "2026-11-08T12:00:00Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Task title is required",
  "path": "/api/tasks"
}
```

## 6. Status codes

| Code | Meaning |
|---|---|
| 200 | Request succeeded |
| 201 | Resource created |
| 204 | Resource deleted successfully |
| 400 | Invalid request data |
| 401 | User is not authenticated |
| 403 | User is not allowed to access the resource |
| 404 | Resource not found |
| 409 | Duplicate or conflicting data |
| 500 | Unexpected server error |
