# SWYNEX Student Task Manager

A student-focused web application for organizing academic tasks, assignments, subjects, and deadlines.

> **Internship Task 1 deliverable:** This repository currently contains the project architecture, database design, API plan, screen plan, and starter folders. The backend and database integration are planned, not yet implemented.

## Project goal

Help students create academic tasks, assign due dates, organize tasks by subject, and monitor pending, completed, and overdue work from one dashboard.

## Proposed technology stack

- Frontend: HTML, CSS, JavaScript
- Backend: Java 17+ and Spring Boot
- Database: MySQL 8.0+
- API style: REST over HTTP using JSON
- API testing: Postman
- Version control: Git and GitHub

## Repository structure

```text
SWYNEX-Project-Architecture/
├── README.md
├── docs/
│   ├── PROJECT_ARCHITECTURE.md
│   ├── API_DOCUMENTATION.md
│   └── ARCHITECTURE_DIAGRAM.md
├── database/
│   └── schema.sql
├── frontend/
│   └── README.md
├── backend/
│   └── README.md
└── .gitignore
```

## Getting started

1. Read `docs/PROJECT_ARCHITECTURE.md`.
2. Review `database/schema.sql`.
3. Review `docs/API_DOCUMENTATION.md`.
4. Follow the implementation plan in the architecture document.
5. Build and test the frontend and backend in later development stages.

## Current status

- [x] Product idea and scope defined
- [x] Data model designed
- [x] API routes documented
- [x] Frontend screens planned
- [x] High-level architecture diagram documented
- [ ] Frontend implementation
- [ ] Spring Boot backend implementation
- [ ] MySQL integration
- [ ] End-to-end testing

## Note

Do not add real passwords, API keys, database credentials, or personal student data to this repository.
